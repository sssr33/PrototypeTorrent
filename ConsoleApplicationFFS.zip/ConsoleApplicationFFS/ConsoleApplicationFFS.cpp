// ConsoleApplicationFFS.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "aligned_allocator.h"

#include <mmintrin.h>
#include <emmintrin.h>
#include <malloc.h>
#include <cstdint>
#include <vector>
#include <windows.h>
#include <algorithm>
#include <DirectXMath.h>
#include <iostream>
#include <conio.h>

union __m128_{
	__m128i i;
	__m128 f;
};

const uint32_t outerTests = 10;
const uint32_t innerTests = 10000;

template<class T>
void TestPerformance(T callable, uint64_t &minTime, uint64_t &maxTime){
	uint64_t _maxTime = 0;
	uint64_t _minTime = UINT64_MAX;

	for (uint32_t i = 0; i < outerTests; i++){
		auto time = GetTickCount64();

		for (uint32_t j = 0; j < innerTests; j++){
			callable();
		}

		time = GetTickCount64() - time;
		_minTime = (std::min)(_minTime, time);
		_maxTime = (std::max)(_maxTime, time);
	}

	minTime = _minTime;
	maxTime = _maxTime;
}

int _tmain(int argc, _TCHAR* argv[])
{
	const uint32_t vecSize = 1024;
	const uint32_t bitfieldSize = 4 * vecSize;
	/*const __m128_ zeros = { 0, 0, 0, 0 };
	const __m128_ c1 = { 0x7f, 0x7f, 0x7f, 0x7f };*/
	std::vector<uint32_t, aligned_allocator<uint32_t, 16>> bitfield;
	std::vector<uint32_t, aligned_allocator<uint32_t, 16>> resultSSE;
	std::vector<uint32_t, aligned_allocator<uint32_t, 16>> resultSSE2;
	std::vector<uint32_t, aligned_allocator<uint32_t, 16>> resultA1;
	std::vector<uint32_t, aligned_allocator<uint32_t, 16>> resultA2;
	std::vector<uint32_t, aligned_allocator<uint32_t, 16>> resultA3;
	__m128_ zeros;
	__m128_ c1, c2;

	__m128_ ands[5];
	__m128_ subs[5];
	__m128_ r32;

	zeros.i = _mm_set_epi32(0, 0, 0, 0);
	c1.i = _mm_set_epi32(0x7f, 0x7f, 0x7f, 0x7f);
	c2.i = _mm_set_epi32(0x7FFFFFFF, 0x7FFFFFFF, 0x7FFFFFFF, 0x7FFFFFFF);

	ands[0].i = _mm_set_epi32(0x0000FFFF, 0x0000FFFF, 0x0000FFFF, 0x0000FFFF);
	ands[1].i = _mm_set_epi32(0x00FF00FF, 0x00FF00FF, 0x00FF00FF, 0x00FF00FF);
	ands[2].i = _mm_set_epi32(0x0F0F0F0F, 0x0F0F0F0F, 0x0F0F0F0F, 0x0F0F0F0F);
	ands[3].i = _mm_set_epi32(0x33333333, 0x33333333, 0x33333333, 0x33333333);
	ands[4].i = _mm_set_epi32(0x55555555, 0x55555555, 0x55555555, 0x55555555);

	subs[0].i = _mm_set_epi32(16, 16, 16, 16);
	subs[1].i = _mm_set_epi32(8, 8, 8, 8);
	subs[2].i = _mm_set_epi32(4, 4, 4, 4);
	subs[3].i = _mm_set_epi32(2, 2, 2, 2);
	subs[4].i = _mm_set_epi32(1, 1, 1, 1);

	r32.i = _mm_set_epi32(32, 32, 32, 32);

	static const int Mod37BitPosition[] = // map a bit value mod 37 to its position
	{
		32, 0, 1, 26, 2, 23, 27, 0, 3, 16, 24, 30, 28, 11, 0, 13, 4,
		7, 17, 0, 25, 22, 31, 15, 29, 10, 12, 6, 0, 21, 14, 9, 5,
		20, 8, 19, 18
	};

	static const int MultiplyDeBruijnBitPosition[32] =
	{
		0, 1, 28, 2, 29, 14, 24, 3, 30, 22, 20, 15, 25, 17, 4, 8,
		31, 27, 13, 23, 21, 19, 16, 7, 26, 12, 18, 6, 11, 5, 10, 9
	};

	bitfield.resize(bitfieldSize);
	resultSSE.resize(bitfieldSize);
	resultSSE2.resize(bitfieldSize);
	resultA1.resize(bitfieldSize);
	resultA2.resize(bitfieldSize);
	resultA3.resize(bitfieldSize);

	for (uint32_t i = 0; i < bitfieldSize; i++){
		/*bitfield[i] = 1 << (i % 32);*/
		bitfield[i] = 0xFFFFFFFF << (i % 32);
	}

	uint64_t minTimeSSE, maxTimeSSE;
	uint64_t minTimeSSE2, maxTimeSSE2;
	uint64_t minTimeA1, maxTimeA1;
	uint64_t minTimeA2, maxTimeA2;
	uint64_t minTimeA3, maxTimeA3;

	TestPerformance([&](){
		for (uint32_t i = 0; i < vecSize; i++){
			/*__m128_ v1, v2, vf;

			v1.i = _mm_load_si128((const __m128i *)&bitfield[i * 4]);
			v2.i = _mm_sub_epi32(zeros.i, v1.i);

			auto tmp = _mm_and_si128(v1.i, v2.i);

			vf.f = _mm_cvtepi32_ps(tmp);
			vf.f = _mm_and_ps(vf.f, c2.f);

			auto tmp2 = _mm_srli_epi32(vf.i, 23);
			auto tmp3 = _mm_sub_epi32(tmp2, c1.i);

			_mm_store_si128((__m128i *)&resultSSE[i * 4], tmp3);*/


			__m128_ v1, v2, vf;

			v1.i = _mm_load_si128((const __m128i *)&bitfield[i * 4]);
			v2.i = _mm_sub_epi32(zeros.i, v1.i);

			v1.i = _mm_and_si128(v1.i, v2.i);

			vf.f = _mm_cvtepi32_ps(v1.i);
			vf.f = _mm_and_ps(vf.f, c2.f);

			v1.i = _mm_srli_epi32(vf.i, 23);
			v2.i = _mm_sub_epi32(v1.i, c1.i);

			_mm_store_si128((__m128i *)&resultSSE[i * 4], v2.i);
		}
	}, minTimeSSE, maxTimeSSE);

	/*TestPerformance([&](){
		for (uint32_t i = 0; i < vecSize; i++){
			__m128_ v1, v2, vr;

			vr = r32;
			v1.i = _mm_load_si128((const __m128i *)&bitfield[i * 4]);

			v2.i = _mm_sub_epi32(zeros.i, v1.i);
			v1.i = _mm_and_si128(v1.i, v2.i);

			auto tmp1 = _mm_and_si128(v1.i, ands[0].i);
			auto tmp2 = _mm_and_si128(v1.i, ands[1].i);
			auto tmp3 = _mm_and_si128(v1.i, ands[2].i);
			auto tmp4 = _mm_and_si128(v1.i, ands[3].i);
			auto tmp5 = _mm_and_si128(v1.i, ands[4].i);

			auto tmp0 = _mm_cmpeq_epi32(v1.i, zeros.i);
			tmp1 = _mm_cmpeq_epi32(tmp1, zeros.i);
			tmp2 = _mm_cmpeq_epi32(tmp2, zeros.i);
			tmp3 = _mm_cmpeq_epi32(tmp3, zeros.i);
			tmp4 = _mm_cmpeq_epi32(tmp4, zeros.i);
			tmp5 = _mm_cmpeq_epi32(tmp5, zeros.i);

			

			_mm_store_si128((__m128i *)&resultSSE[i * 4], vr.i);
		}
	}, minTimeSSE2, maxTimeSSE2);*/

	TestPerformance([&](){
		for (uint32_t i = 0; i < bitfieldSize; i++){
			uint32_t v = bitfield[i];
			resultA1[i] = Mod37BitPosition[(-v & v) % 37];
		}
	}, minTimeA1, maxTimeA1);

	TestPerformance([&](){
		for (uint32_t i = 0; i < bitfieldSize; i++){
			uint32_t v = bitfield[i];
			resultA2[i] = MultiplyDeBruijnBitPosition[((uint32_t)((v & -v) * 0x077CB531U)) >> 27];
		}
	}, minTimeA2, maxTimeA2);

	TestPerformance([&](){
		for (uint32_t i = 0; i < bitfieldSize; i++){
			uint32_t v = bitfield[i];
			float f = (float)(v & -v);
			resultA3[i] = (*(uint32_t *)&f >> 23) - 0x7f;
		}
	}, minTimeA3, maxTimeA3);



	for (uint32_t i = 0; i < bitfieldSize; i++){
		bool test1 = resultSSE[i] != resultA1[i];
		bool test2 = resultSSE[i] != resultA2[i];
		bool test3 = resultSSE[i] != resultA3[i];
		bool test4 = false;// resultSSE[i] != resultSSE2[i];

		if (test1 || test2 || test3 || test4){
			if (test1){
				std::cout << "Failed at test1 " << i << std::endl;
			}

			if (test2){
				std::cout << "Failed at test2 " << i << std::endl;
			}

			if (test3){
				std::cout << "Failed at test3 " << i << std::endl;
			}

			if (test4){
				std::cout << "Failed at test4 " << i << std::endl;
			}
		}
	}

	std::cout << "SSE min ms : " << minTimeSSE << " max ms : " << maxTimeSSE << std::endl;
	std::cout << "SSE2 min ms : " << minTimeSSE2 << " max ms : " << maxTimeSSE2 << std::endl;
	std::cout << "A1_ min ms : " << minTimeA1 << " max ms : " << maxTimeA1 << std::endl;
	std::cout << "A2_ min ms : " << minTimeA2 << " max ms : " << maxTimeA2 << std::endl;
	std::cout << "A3_ min ms : " << minTimeA3 << " max ms : " << maxTimeA3 << std::endl;

	_getch();
	return 0;
}

